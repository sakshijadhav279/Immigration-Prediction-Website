const express = require('express')
const app = express()
const port = 4010;
const ejs = require('ejs');

const {MongoClient} = require('mongodb')
const url = 'mongodb://localhost:27017/'
const client = new MongoClient(url);

const getData = async(req, res)=>{
    let re = await client.connect();
    let data= await re.db('kaya');
    return data.collection('registered')

}


app.set('view engine', 'ejs');
app.use(express.json())
app.use(express.static('public'));

app.get('/home', async(req, res)=>{
    res.render('index');
    res.end()
})

app.post('', async(req, res)=>{
    let myData = req.body;
    let coll = await getData();
    let re = coll.insertOne(req.body)
    console.log(myData, re)
    res.end()
})

app.post('/login', async(req, res)=>{
    let myData = await req.body;
    console.log(myData)
    after(myData)
})

const after = async (myData)=>{
    app.get('/dashboard',async(req, res)=>{

        let coll = await getData();
        let result = await coll.find({email:myData.email, password: myData.password}).toArray();
        let data = result[0];
        console.log(result)
        res.render('after.ejs', data)
        res.end()
    })
}
app.listen(port);